#ifndef __SMBUS_H
#define __SMBUS_H


#include "stm32f1xx_hal.h"




#define    SMBUS_SCL_H()       HAL_GPIO_WritePin(SMBus_SCL_GPIO_Port, SMBus_SCL_Pin, GPIO_PIN_SET);
#define    SMBUS_SCL_L()       HAL_GPIO_WritePin(SMBus_SCL_GPIO_Port, SMBus_SCL_Pin, GPIO_PIN_RESET);
#define    SMBUS_SDA_H()       HAL_GPIO_WritePin(SMBus_SDA_GPIO_Port, SMBus_SDA_Pin, GPIO_PIN_SET);
#define    SMBUS_SDA_L()       HAL_GPIO_WritePin(SMBus_SDA_GPIO_Port, SMBus_SDA_Pin, GPIO_PIN_RESET);

#define    SMBUS_SDA_READ()     HAL_GPIO_ReadPin(SMBus_SDA_GPIO_Port, SMBus_SDA_Pin)




void delay_us(uint16_t  N);	// use TIM3 to produce delay
void  SMBus_Start(void);
void  SMBus_Stop(void);
void  SMBus_M_To_S_Ack(void);
uint8_t  SMBus_S_To_M_Ack(void);
void  SMBus_Send_Byte(uint8_t byteData);
uint8_t  SMBus_Read_Byte(void);


#endif

