#ifndef __MLX90614_H
#define __MLX90614_H


#include "stm32f1xx_hal.h"


#define   MLX90614_ADDR_WRITE   0x00	
#define   MLX90614_ADDR_READ    0x01

#define   MLX90614_RAM    0x00

#define   AMBIENT_TEMP    0x06
#define   OBJECT_TEMP     0x07


extern uint8_t     RxBuffer[3];

float   MLX90614_Read_TempData(uint8_t  ambient_or_object);
	

#endif


