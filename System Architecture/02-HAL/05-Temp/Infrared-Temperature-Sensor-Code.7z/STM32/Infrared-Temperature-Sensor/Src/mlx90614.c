#include "stm32f1xx_hal.h"
#include "tim.h"
#include "mlx90614.h"
#include "smbus.h"



uint8_t     RxBuffer[3];



/***************************************************************************
* @brief      Read object temperature(Tobj) from  RAM registers of MLX90614
* @param      ambient_or_object : Which temperature you want to get
* @retval     Object temperature
****************************************************************************/
float   MLX90614_Read_TempData(uint8_t  ambient_or_object)
{
	uint32_t  temp_data;	
	float  T;	

	SMBus_Start(); 
	SMBus_Send_Byte(MLX90614_ADDR_WRITE);
	SMBus_S_To_M_Ack();
	SMBus_Send_Byte(ambient_or_object);
	SMBus_S_To_M_Ack();
	SMBus_Start(); 
	SMBus_Send_Byte(MLX90614_ADDR_READ);
	SMBus_S_To_M_Ack();
	RxBuffer[0] = SMBus_Read_Byte();
	SMBus_M_To_S_Ack();
	RxBuffer[1] = SMBus_Read_Byte();
	SMBus_M_To_S_Ack();
	RxBuffer[2] = SMBus_Read_Byte();
	SMBus_M_To_S_Ack();
	SMBus_Stop();
	
	temp_data = RxBuffer[1]*256 + RxBuffer[0];	
	if(temp_data >= 0x8000)	   // if MSB bit is "1", this data is error 
	{
		return 0;
	}
	
	if(temp_data == 0)	 
	{
		return 0;
	}
	
	T = temp_data*0.02;
	if(T >= 273.15)	
	{
		return (T - 273.15);
	}
	else
	{
		return  -(273.15 - T);
	}		
}

