#include "stm32f1xx_hal.h"
#include "tim.h"	// use TIM3 to produce delay
#include "smbus.h"	// use TIM3 to produce delay



/***************************************************************************
* @brief      Delay for N us
* @param      N: How many us you want to delay
* @retval     None
****************************************************************************/
void delay_us(uint16_t  N)
{
	uint16_t differ=0xffff-N-5;
	
	__HAL_TIM_SET_COUNTER(&htim3,differ);	// use TIM3 to produce delay
	HAL_TIM_Base_Start(&htim3);

	while(differ<0xffff-5)
	{
		differ=__HAL_TIM_GET_COUNTER(&htim3);
	}

	HAL_TIM_Base_Stop(&htim3);
}

/***************************************************************************
* @brief      SMBus start bit
* @param      None
* @retval     None
****************************************************************************/
void  SMBus_Start(void)
{
	SMBUS_SDA_H();
	SMBUS_SCL_H();
	delay_us(5);
	SMBUS_SDA_L();
	delay_us(5);
	SMBUS_SCL_L();
	delay_us(5);
}

/***************************************************************************
* @brief      SMBus stop bit
* @param      None
* @retval     None
****************************************************************************/
void  SMBus_Stop(void)
{
	delay_us(5);
	SMBUS_SDA_L();
	delay_us(5);
	SMBUS_SCL_H();
	delay_us(5);
	SMBUS_SDA_H();
	delay_us(5);
}

/***************************************************************************
* @brief      Ack form master to slaver
* @param      None
* @retval     None
****************************************************************************/
void  SMBus_M_To_S_Ack(void)
{
	SMBUS_SCL_L();
	SMBUS_SDA_L();
	delay_us(6);
	SMBUS_SCL_H();
	delay_us(6);
	SMBUS_SCL_L();
	delay_us(6);
	SMBUS_SDA_H();	// Master must release the SDA after Ack !!!
	delay_us(6);
}

/***************************************************************************
* @brief      Ack form slaver to master
* @param      None
* @retval     0: Salver Ack
	  Other: Slaver No Ack 
****************************************************************************/
uint8_t  SMBus_S_To_M_Ack(void)
{	
	SMBUS_SCL_L();
	delay_us(6);
	SMBUS_SDA_H();	// Master must release the SDA to wait the Ack from slaver !!!
	delay_us(6);
	if(SMBUS_SDA_READ() == GPIO_PIN_RESET)
	{
		SMBUS_SCL_H();
		delay_us(6);
		if(SMBUS_SDA_READ() == GPIO_PIN_RESET)
		{
			SMBUS_SCL_L();
			delay_us(6);
			if(SMBUS_SDA_READ() == GPIO_PIN_SET)
			{
				return 0;   // Slaver Ack 
			}
			return 1;
		}
		return 2;
	}
	return 3;  
}

/***************************************************************************
* @brief      Master send one byte to slaver
* @param      byteData : the byte data you want to send
* @retval     None
****************************************************************************/
void  SMBus_Send_Byte(uint8_t byteData)
{
	uint8_t  i;
	uint8_t  temp = 0x80;
	
	for(i = 0; i < 8; i++)
	{
		SMBUS_SCL_L();
		delay_us(6);
		if((byteData & temp) == 0)	
		{	
			SMBUS_SDA_L();	
		}
		else	
		{
			SMBUS_SDA_H();
		}
		temp >>= 1;
		delay_us(6);
		SMBUS_SCL_H();
		delay_us(6);
	}
}

/***************************************************************************
* @brief      Master read one byte from slaver
* @param      None
* @retval     Received byte
****************************************************************************/
uint8_t  SMBus_Read_Byte(void)
{
	uint8_t  i;
	uint8_t  byteData;
	uint8_t  temp = 0x80;
		
	delay_us(6);
	for(i = 0; i < 8; i++)
	{
		SMBUS_SCL_L();
		delay_us(6);
		if(SMBUS_SDA_READ() == GPIO_PIN_RESET)
			byteData &= ~temp;
		else	
			byteData |= temp;	
		temp >>= 1;
		SMBUS_SCL_H();
		delay_us(6);		
	}
	return 	byteData;
}


